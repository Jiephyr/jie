<?php 

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    require_once 'db.php';
    $user = $_POST['name'];  
    $pwd = $_POST['pwd'];   

    $sql = "SELECT * FROM users WHERE usr = ? AND pwd = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $user, $pwd); 
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        header("Location: ../sample.php");
    exit;
    } else {
        echo '<script>alert("Invalid username or password"); setTimeout(function(){ window.location.href = "../login.php"; }, 10);</script>';
        exit;
    }

    $stmt->close();
    $conn->close();
}
