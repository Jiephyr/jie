<?php

$db_server = "localhost";
$db_name = "root";
$db_pwd = "";
$db = "db_webdev";


try{
    $conn = mysqli_connect($db_server, $db_name, $db_pwd, $db);
}
catch(mysqli_sql_exception ){
    echo "couldn't connect";
}