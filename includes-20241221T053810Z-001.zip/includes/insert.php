<?php 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include( 'db.php');

    $name = $_POST["name"];
    $pwd = $_POST["pwd"];
    $bday = $_POST["bday"];

    $query = "INSERT INTO users (usr, pwd, bday)
              VALUES ('$name', '$pwd', '$bday')";

    $sql = mysqli_query($conn, $query);

    header("Location: ../sample.php");
}
